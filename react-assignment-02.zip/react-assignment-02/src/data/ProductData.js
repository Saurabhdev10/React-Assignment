export default  {
    products:[
        {
            "id":1,
            "productName":"Moto G5",
            "quantity":2,
            "price":"Rs 13000"
        },
        {
            "id":2,
            "productName":"Racold Geyser",
            "quantity":3,
            "price":"Rs 6000"
        },
        {
            "id":3,
            "productName":"Dell Inspiron",
            "quantity":4,
            "price":"Rs 50000"
        }
    ]
};