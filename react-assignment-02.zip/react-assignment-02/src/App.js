//import logo from './logo.svg';
import './App.css';
import AllProductsPage from './Components/AllProductsPage';

function App() {
  return (
    <>
    <AllProductsPage />
    </>
  );
}

export default App;
