import React from "react";
import Product from "./Product";

export default class ProductList extends React.Component {
  render() {
    let commentNodes = this.props.products.map((product) => (
      <Product
        key={product.id}
        id={product.id}
        productName={product.productName}
        quantity={product.quantity}
        price={product.price}
      >
        {/* What goes here? */}
      </Product>
    ));

    return (
      <>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Product Name</th>
              <th>Quantity</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>{commentNodes}</tbody>
        </table>
      </>
    );
  }
}
