import React from 'react';
import ProductList from './ProductList';
class Products extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      products: []
    };
  }
  render() {
    return (
      <>
      <ProductList/>
      </>
      
    );
  }
}

export default Products;