import React from 'react';
import axios from 'axios';
import './style.css';

class ProductList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      products: []
    };
  }

  componentDidMount() {
    fetch('http://localhost:3001/products')
      .then(response => response.json())
      .then(data => this.setState({ products: data }))
      .catch(error => console.error('Error fetching products:', error));
  }

  render() {
    return (
      <div>
        <h1>Product List</h1>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Product Name</th>
              <th>Quantity</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            {this.state.products.map(product => (
              <tr key={product.ID}>
                <td>{product.ID}</td>
                <td>{product.ProductName}</td>
                <td>{product.Quantity}</td>
                <td>{product.Price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

export default ProductList;
