import React from "react";
import Table from './Table';
import {Link} from 'react-router-dom';

export default function Product(){
    return(
        <div style={{textAlign:"center",margin:"2rem"}}>
            <Link to="/add-product">
                <button style={{padding:"4px",borderRadius: "4px",margin:"1rem"}}>
                    Add Button
                </button>
            </Link>
            <Table/>
            
            <h2 style={{color: "lightgrey"}}></h2>
        </div>
    );
}