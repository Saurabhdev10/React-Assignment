import React from "react";
import { Routes, Route } from "react-router-dom";
import About from './About';
import Product from './Product';
import AddProduct from './AddProduct';
import ProductDetails from './ProductDetails';

export default function NavRoutes(){
    return(
        <>
        <div>
            <Routes>
                <Route path="*" element={<About/>} />
                <Route path="/about" element={<About/>} />
                <Route path="/product" element={<Product/>} />
                <Route path="/product/:productName" element={<ProductDetails/>} />
                <Route path="/add-product" element={<AddProduct/>} />
            </Routes>
        </div>
        </>
    )
}