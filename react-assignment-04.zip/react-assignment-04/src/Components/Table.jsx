import React, { useContext } from "react";

import { useEffect } from "react";
import axios from "axios";
import { RecordContext } from "./ContextProvider";
import { useNavigate } from "react-router-dom";

export default function Table() {
  const recordContext = useContext(RecordContext);
  const navigate = useNavigate();

  useEffect(() => {
    axios
    .get("http://localhost:3000/products")
    .then((d) => recordContext.setState(d.data))
    .catch((err) => alert("Internal Server Error"));
  },[]);

  const handleClick=(productName) =>(e) =>{
    let data =window.confirm("Are you sure you want to view the details ?");
    console.log(data);
    if(data){
        navigate("./"+productName);
    }
  };
  return(
    <>
    <main>
        <h1>Product List</h1>
        <table
        style={{
            border:" 1px solid black",
            margin:"3rem auto",
            borderRadius:"4px",
            padding:"8px",
            textAlign:"center"
        }}
        >
            <thead>
                <tr>
                    <th style={{ border: "1px solid grey" ,borderRadius :"3px"}}>
                        Product Name
                    </th>
                    <th style={{ border: "1px solid grey" ,borderRadius :"3px"}}>
                        Quantity
                    </th>
                    <th style={{ border: "1px solid grey" ,borderRadius :"3px"}}>
                        Price
                    </th>
                </tr>
            </thead>
            <tbody>
                {recordContext?.state?.map((r) => {
                    return(
                        <tr key={r.id}>
                            <td onClick={handleClick(r.productName)}>{r.productName}</td>
                            <td>{r.quantity}</td>
                            <td>Rs . {r.price}</td>  
                        </tr>
                    );
                })}
            </tbody>
        </table>
    </main>
    </>
  );
}
