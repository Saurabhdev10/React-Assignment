import React from 'react';


function About(){
    return(
        <div>
            <h1
            style={{
                textAlign:"center",
                color:"purple",
                fontFamily:"Georgia,'Times New Roman',Times,serif",
                marginTop:"5rem"
            }}
            >
                About : This Application provides information about the products
            </h1>
        </div>
    )
}

export default About;