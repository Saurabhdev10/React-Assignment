import { useContext } from "react";
import { useFormik } from "formik";
import { nanoid } from "nanoid";
import axios from "axios";
import "./style.css";
import { RecordContext } from "./ContextProvider";
import { useNavigate } from "react-router-dom";
import { formValidate } from "./validation";

function AddProduct() {
  const recordContext = useContext(RecordContext);
  const navigate = useNavigate();
  const initialValues = {
    productName: "",
    quantity: null,
    price: null,
  };

  const { values, handleChange, handleSubmit, errors } = useFormik({
    initialValues: initialValues,
    validationSchema: formValidate,
    onSubmit: (values) => {
      const id = nanoid();
      values["id"] = id;
      console.log(values);

      axios
        .post("http://localhost:3000/products", values)
        .then((d) => {
          recordContext.setState((prev) => [...prev, values]);
          navigate("/product");
        })
        .catch((err) => alert("some error occured"));
    },
  });
  
  return(
    <>
    <div
    style={{
        border:"1px solid black",
        width :"35%",
        margin:"1rem auto",
        textAlign: "center",
        padding:"20px",
        borderRadius:"10px"
    }}
    >
        <form onSubmit={handleSubmit}>
            <label htmlFor="productName"> Product Name:</label>
            <input
                type="text"
                placeholder="Enter Product Name"
                name="productName"
                onChange={handleChange}
                value={values.productName}   
            />
            {errors.productName&& <small>{errors.productName}</small>} <br />
            <br/>
            <label htmlFor="quantity"> Quantity:</label>
            <input
                type="text"
                placeholder="Enter Quantity"
                name="quantity"
                onChange={handleChange}
                value={values.quantity}   
            />
            {errors.quantity&& <small>{errors.quantity}</small>} <br />
            <br/>
            <label htmlFor="price"> Price:</label>
            <input
                type="text"
                placeholder="Enter Price"
                name="price"
                onChange={handleChange}
                value={values.price}   
            />
            {errors.price&& <small>{errors.price}</small>} 
            <br/>
            <br/>
            <button 
            style={{
                backgroundColor:"lightgreen",
                padding:"5px",

                borderRadius:"5px",
            }}
            >
                Submit
            </button>
        </form>
    </div>
    <br />
    <br />
    </>
  )
}

export default AddProduct;