import React from "react";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";

export default function ProductDetails(){
    let {productName}=useParams();
    let navigate=useNavigate();
    return(
        <>
        <div 
        style={{
            fontFamily:"Georgia, 'Times New Roman',Times, serif",
            fontWeight:"bold",
            margin:"1rem"
        }}
        >
            Product Details :{productName}
        </div>
        <button
        style={{
            marginLeft:"5rem",
            backgroundColor:"gray",
            color:"white",
            padding:"5px",
            borderRadius:"5px"
        }}
        onClick={()=>navigate(-1)}
        >
            Back
        </button>
        </>
    );
}