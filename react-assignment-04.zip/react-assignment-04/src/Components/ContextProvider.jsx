import React ,{ createContext,useState } from "react";

export const RecordContext=createContext({});

//context creation
export default function ContextProvider({children}){
    const [state,setState] =useState([])

    return(

        <RecordContext.Provider value={{state,setState}}>
            {children}
        </RecordContext.Provider>
    )
}
