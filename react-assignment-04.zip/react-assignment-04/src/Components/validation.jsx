import * as Yup from 'yup';

export const formValidate=Yup.object({
    productName:Yup.string().required("Product Name is required"),
    quantity:Yup.number().required("Quantity is required"),
    price:Yup.number().required("Price is required")
}) 