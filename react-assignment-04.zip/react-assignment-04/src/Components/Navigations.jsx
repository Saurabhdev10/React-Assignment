import React from "react";
import { Link } from "react-router-dom";
import '../Components/style.css';


function Navigations (){
    return(
        <>
        <div className="nav"> 
            <div className="navItems">
                <Link to="about">About</Link>
            </div>
            <div className="navItems">
                <Link to="product">Products</Link>
            </div>
        </div>
        
        </>
    );
}
 export default Navigations