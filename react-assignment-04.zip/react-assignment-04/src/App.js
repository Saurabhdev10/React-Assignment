//import logo from './logo.svg';
import './App.css';
import Navigations from './Components/Navigations';
import NavRoutes from './Components/NavRoutes';
import ContextProvider from './Components/ContextProvider';

function App() {
  return (
    <ContextProvider>
      <div className='App'>
        <Navigations/>
        <NavRoutes />
      </div>
    </ContextProvider>
  );
}

export default App;
