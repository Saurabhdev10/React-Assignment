import React, { useState, useEffect } from 'react';
import ProductList from './ProductList';

function Products() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3001/products')
      .then(response => response.json())
      .then(data => setProducts(data))
      .catch(error => console.error('Error fetching products:', error));
  }, []);

  return (
    <>
      <ProductList products={products} />
    </>
  );
}

export default Products;
