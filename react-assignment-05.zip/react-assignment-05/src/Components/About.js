import React from 'react';

function About() {
  return (
    <div>
      <h1>About (using Functional Components): This application provides information about products</h1>
    </div>
  );
}

export default About;
