import React from 'react';
import { BrowserRouter as Router, Route, Link, Switch } from 'react-router-dom';
import About from './Components/About';
import Products from './Components/Products';
import './index.css';

function App() {
  return (
    <Router>
      <div className="App">
        <nav>
          <ul>
            <li>
              <Link to="/">About</Link>
            </li>
            <li>
              <Link to="/products">Products</Link>
            </li>
          </ul>
        </nav>
        <Switch>
          <Route path="/" exact component={About} />
          <Route path="/products" component={Products} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
